import datetime
import gzip
import json
from pathlib import Path
import subprocess
import time

output_dir = Path('/tmp/issue10-paired-measurements')
output_dir.mkdir(exist_ok=True)
expected_producer = 'edb7345ed03dca50066737d421b4643b26f870435a964fb20379c23a77983ff9'


def command(args, **kwargs):
    return subprocess.run(['rtk', 'proxy', *args], check=True, **kwargs)


def read(args):
    return command(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout.strip()


def progress(side, stage):
    (output_dir / 'progress.json').write_text(json.dumps({
        'side': side, 'stage': stage,
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }) + '\n')


for side in ['before', 'after']:
    image = f'pg-mdm:issue10-final-measurement-{side}'
    container = f'issue10-measure-{side}'
    root = output_dir / side
    root.mkdir(exist_ok=True)
    progress(side, 'starting')
    command(['docker', 'run', '--detach', '--name', container, '--cpus=2', '--memory=4g',
             '-e', 'POSTGRES_PASSWORD=postgres', '-e', 'PGOPTIONS=-c jit=off', image], stdout=subprocess.DEVNULL)
    try:
        for _ in range(120):
            logs = read(['docker', 'logs', container])
            ready = subprocess.run(['rtk', 'proxy', 'docker', 'exec', container,
                                    'pg_isready', '-U', 'postgres'], capture_output=True)
            if 'PostgreSQL init process complete' in logs and ready.returncode == 0:
                break
            time.sleep(1)
        else:
            raise RuntimeError('database startup did not complete')
        producer = read(['docker', 'exec', container, 'sha256sum',
                         '/usr/lib/postgresql/18/lib/pg_trickle.so']).split()[0]
        assert producer == expected_producer, (side, producer)
        progress(side, 'setup')
        with (root / 'setup.log').open('w') as stream:
            command(['docker', 'exec', container, 'psql', '-X', '-v', 'ON_ERROR_STOP=1',
                     '-U', 'postgres', '-f', '/tests/measurement-setup.sql'],
                    stdout=stream, stderr=subprocess.STDOUT)
        logical_ids = json.loads(read(['docker', 'exec', container,
            'psql', '-X', '-At', '-U', 'postgres', '-d', 'foundation', '-c',
            "SELECT jsonb_agg(m.logical_id ORDER BY m.topological_ordinal) FROM mdm_internal.graph_members m JOIN mdm_internal.graph_bindings g USING (graph_binding_id) JOIN mdm_internal.entities e USING (entity_id) WHERE e.entity_name='customer'"]))
        shared = ['candidate-raw/customer', 'candidate-set/customer']
        assert all((name in logical_ids) == (side == 'after') for name in shared), (side, logical_ids)
        image_info = json.loads(read(['docker', 'image', 'inspect', image]))[0]
        info = json.loads(read(['docker', 'inspect', container]))[0]
        metadata = {
            'side': side, 'image': image, 'image_id': image_info['Id'],
            'architecture': image_info['Architecture'], 'labels': image_info['Config']['Labels'],
            'producer_binary_sha256': producer,
            'setup_graph_logical_ids': logical_ids,
            'session_settings': json.loads(read(['docker', 'exec', container,
                'psql', '-X', '-At', '-U', 'postgres', '-d', 'foundation', '-c',
                "SELECT jsonb_build_object('jit',current_setting('jit'),'work_mem',current_setting('work_mem'),'max_parallel_workers_per_gather',current_setting('max_parallel_workers_per_gather'))"])),
            'qualification_strategy': 'differential',
            'qualification_sql_sha256': read(['docker', 'exec', container, 'sha256sum',
                                              '/tests/incremental_qualification.sql']).split()[0],
            'adapter_binary_sha256': read(['docker', 'exec', container, 'sha256sum',
                                          '/usr/lib/postgresql/18/lib/pg_mdm.so']).split()[0],
            'nano_cpus': info['HostConfig']['NanoCpus'],
            'memory_bytes': info['HostConfig']['Memory'],
            'docker_environment': json.loads(read(['docker', 'info', '--format',
                '{"cpus":{{.NCPU}},"memory_bytes":{{.MemTotal}},"architecture":"{{.Architecture}}","version":"{{.ServerVersion}}"}'])),
            'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'database_counters_before': json.loads(read(['docker', 'exec', container,
                'psql', '-X', '-At', '-U', 'postgres', '-d', 'foundation', '-c',
                "SELECT to_jsonb(s) FROM pg_stat_database s WHERE datname='foundation'"])),
        }
        assert metadata['session_settings']['jit'] == 'off'
        if side == 'after':
            assert metadata['adapter_binary_sha256'] == '46c967d9f0f2c0fa2a2c0fd925e702a42cbc8b8cce80a428bd8abcbbc1310cdf'
        else:
            assert metadata['adapter_binary_sha256'] == '383b4be673b8fb109cf28ca935e2b2a4753a7ef07847af164ce614ed21bf0b46'
        progress(side, 'measuring')
        with (root / 'qualification.json').open('w') as result, (root / 'qualification.log').open('w') as log:
            command(['docker', 'exec', container, 'psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1',
                     '-v', 'producer_artifact_sha256=b8d4c59ca3770c305659255e09adde303b4d220228392c415ae363aa7be0a2da',
                     '-U', 'postgres', '-d', 'foundation', '-f', '/tests/incremental_qualification.sql'],
                    stdout=result, stderr=log)
        result = json.loads((root / 'qualification.json').read_text())
        assert result['equivalence_checks'] == 70
        assert len(result['samples']) == 70
        assert len(result['additional_workloads']) == 3
        metadata['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        metadata['database_counters_after'] = json.loads(read(['docker', 'exec', container,
            'psql', '-X', '-At', '-U', 'postgres', '-d', 'foundation', '-c',
            "SELECT to_jsonb(s) FROM pg_stat_database s WHERE datname='foundation'"]))
        (root / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print(side, 'passed 70 rebuild comparisons and 3 additional workloads', flush=True)
    finally:
        progress(side, 'retaining logs')
        with gzip.open(root / 'postgres.log.gz', 'wb') as destination:
            process = subprocess.Popen(['rtk', 'proxy', 'docker', 'logs', container],
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            while chunk := process.stdout.read(1024 * 1024):
                destination.write(chunk)
            process.wait()
        command(['docker', 'stop', container], stdout=subprocess.DEVNULL)
progress('both', 'complete')
