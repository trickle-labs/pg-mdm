\set ON_ERROR_STOP on
CREATE ROLE mdm_helper_owner NOLOGIN NOSUPERUSER NOBYPASSRLS;
CREATE ROLE mdm_administrator NOLOGIN NOSUPERUSER NOBYPASSRLS;
CREATE ROLE mdm_test_login LOGIN NOSUPERUSER NOBYPASSRLS;
GRANT mdm_administrator TO mdm_test_login WITH SET TRUE, INHERIT FALSE;
CREATE DATABASE foundation;
\connect foundation postgres
CREATE EXTENSION pg_trickle;
CREATE EXTENSION pg_mdm;
GRANT SELECT ON ALL TABLES IN SCHEMA pgtrickle TO mdm_administrator;
\set helper_owner mdm_helper_owner
\i /sql/configure_helper.sql
GRANT USAGE ON SCHEMA mdm, mdm_admin TO mdm_administrator;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA mdm, mdm_admin TO mdm_administrator;
CREATE TABLE public.crm_customer (id bigint PRIMARY KEY, display_name text NOT NULL, email_address text, updated_at timestamptz NOT NULL);
GRANT SELECT, MAINTAIN ON public.crm_customer TO mdm_administrator;
\connect foundation mdm_test_login
SET ROLE mdm_administrator;
SELECT * FROM mdm.create('{"execution_role": "mdm_administrator", "fields": [{"cleaner": "email", "cleaner_options": {}, "display": "masked", "name": "email", "type": "text"}, {"cleaner": "company_name", "cleaner_options": {}, "display": "masked", "name": "name", "type": "text"}], "golden_values": [{"field": "name", "policy": "prefer_source", "sources": ["crm"]}], "limits": {"max_active_records": 100000, "max_automatic_edges": 1000000, "max_block_records": 10000, "max_candidate_pairs": 1000000, "max_comparator_work": 1000000, "max_component_checks": 1000000, "max_decision_closure": 10000, "max_records_per_component": 100000, "warning_block_records": 5000}, "matches": [{"candidate": {"field": "email", "kind": "exact"}, "comparison": "exact", "evidence_group": "email", "fields": ["email"], "name": "same_email", "strength": "identity", "threshold": null}], "name": "customer", "preset": null, "sources": [{"authority": {}, "fields": {"email": "email_address", "name": "display_name"}, "mode": "tracked", "name": "crm", "relation": "public.crm_customer", "row_changed_at": "updated_at", "soft_delete_when": null, "source_id": ["id"]}]}'::jsonb);
RESET ROLE;
