import bisect
import collections
import datetime
import gzip
import json
from pathlib import Path
import re

root = Path('/tmp/issue10-paired-measurements')
stamp = re.compile(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+) UTC ')
rows = re.compile(r'actual rows=([\d.]+) loops=(\d+)')
all_sides = {}


def epoch(value):
    return datetime.datetime.fromisoformat(value).timestamp()


for side in ['before', 'after']:
    data = json.loads((root / side / 'qualification.json').read_text())
    blocks = next(g['relation_name'].split('.')[-1].strip('"') for g in data['graph'] if g['logical_id'] == 'blocks/same_email')
    windows = []
    for source_event in data['graph_refresh_history']:
        if source_event['logical_id'] != 'records/crm' or source_event['rows_inserted'] not in [128, 2048]:
            continue
        bound = source_event['tick_watermark_lsn']
        group = 'population_load_' + str(source_event['rows_inserted'])
        for event in data['graph_refresh_history']:
            if event['tick_watermark_lsn'] == bound and event['logical_id'].startswith(('candidate-', 'pairs/', 'pair-stats/')):
                windows.append((epoch(event['start_time']), epoch(event['end_time']), group, event['logical_id']))
    for sample in data['samples']:
        if not sample['measured']:
            continue
        bound = sample['result']['source_boundary']['safe_bound']
        for event in data['graph_refresh_history']:
            if event['tick_watermark_lsn'] == bound and event['logical_id'].startswith(('candidate-', 'pairs/', 'pair-stats/')):
                windows.append((epoch(event['start_time']), epoch(event['end_time']), str(sample['population']), event['logical_id']))
    for workload in data['additional_workloads']:
        bound = workload['result']['source_boundary']['safe_bound']
        for event in data['graph_refresh_history']:
            if event['tick_watermark_lsn'] == bound and event['logical_id'].startswith(('candidate-', 'pairs/', 'pair-stats/')):
                windows.append((epoch(event['start_time']), epoch(event['end_time']), workload['workload'], event['logical_id']))
    windows.sort()
    starts = [w[0] for w in windows]
    totals = collections.defaultdict(lambda: {'plans_with_block_scans': 0, 'scan_operators': 0, 'scan_loops': 0, 'approximate_rows_visited': 0})
    examples = {}

    def consume(timestamp, lines):
        if timestamp is None:
            return
        index = bisect.bisect_right(starts, timestamp) - 1
        if index < 0 or timestamp > windows[index][1]:
            return
        _, _, population, logical_id = windows[index]
        scans = [line.strip() for line in lines if re.search(r'\bon (?:mdm_graph\.)?' + re.escape(blocks) + r'\b', line) and rows.search(line)]
        if not scans:
            return
        key = population + ':' + logical_id
        total = totals[key]
        total['plans_with_block_scans'] += 1
        total['scan_operators'] += len(scans)
        for line in scans:
            match = rows.search(line)
            total['scan_loops'] += int(match[2])
            total['approximate_rows_visited'] += float(match[1]) * int(match[2])
        examples.setdefault(key, []).append({'logged_at': timestamp, 'sql_and_plan': ''.join(lines)})

    timestamp, lines = None, []
    with gzip.open(root / side / 'postgres.log.gz', 'rt') as stream:
        for line in stream:
            match = stamp.match(line)
            if match:
                consume(timestamp, lines)
                timestamp, lines = None, []
                if 'duration:' in line and 'plan:' in line:
                    timestamp = epoch(match[1].replace(' ', 'T') + '+00:00')
            elif timestamp is not None:
                lines.append(line)
        consume(timestamp, lines)
    all_sides[side] = {'block_relation': blocks, 'work': dict(totals), 'examples': examples}
    assert totals, side
(root / 'plan-work.json').write_text(json.dumps(all_sides, indent=2) + '\n')
print(json.dumps({side: value['work'] for side, value in all_sides.items()}, indent=2))
