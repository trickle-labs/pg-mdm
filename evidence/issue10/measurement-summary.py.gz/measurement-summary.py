import collections
import json
import math
from pathlib import Path

root = Path('/tmp/issue10-paired-measurements')


def percentile(values, fraction):
    values = sorted(values)
    rank = (len(values) - 1) * fraction
    lower = math.floor(rank)
    upper = math.ceil(rank)
    return values[lower] + (values[upper] - values[lower]) * (rank - lower)


assert percentile([1, 2, 3, 4], .5) == 2.5
assert math.isclose(percentile([1, 2, 3, 4], .95), 3.85)
summary = {'profile': 'PostgreSQL 18.4; identical patched producer; 2 CPUs; 4 GiB; JIT off; auto_explain analyze on, timing off', 'sides': {}}
for side in ['before', 'after']:
    directory = root / side
    data = json.loads((directory / 'qualification.json').read_text())
    metadata = json.loads((directory / 'metadata.json').read_text())
    assert data['equivalence_checks'] == 70
    assert len(data['samples']) == 70
    assert metadata['producer_binary_sha256'] == 'edb7345ed03dca50066737d421b4643b26f870435a964fb20379c23a77983ff9'
    assert metadata['nano_cpus'] == 2_000_000_000
    assert metadata['memory_bytes'] == 4_294_967_296
    assert metadata['session_settings'] == {'jit': 'off', 'work_mem': '4MB', 'max_parallel_workers_per_gather': '2'}
    output = {'metadata': metadata, 'populations': [], 'additional_workloads': [], 'ordinary_node_work': {}}
    ordinary = []
    for population in [128, 2048]:
        samples = [s for s in data['samples'] if s['population'] == population]
        measured = [s for s in samples if s['measured']]
        assert len(samples) == 35 and len(measured) == 30
        assert [s['sample'] for s in measured] == list(range(6, 36))
        reported = next(p for p in data['populations'] if p['population'] == population)
        row = {'population': population, 'warmup_samples': 5, 'measured_samples': 30}
        for field in ['elapsed_ms', 'graph_refresh_ms', 'mdm_resolution_ms', 'publication_ms']:
            row[field] = {label: percentile([s[field] for s in measured], quantile) for label, quantile in [('p50', .5), ('p95', .95)]}
            assert abs(row[field]['p95'] - reported[field]['p95']) < .00051, (side, population, field)
        row['strategies'] = dict(collections.Counter(s['result']['resolver_strategy'] for s in measured))
        row['fallbacks'] = dict(collections.Counter(str(s['result']['resolver_fallback_reason']) for s in measured))
        row['affected_records'] = sorted(set(s['result']['affected_records'] for s in measured))
        row['affected_components'] = sorted(set(s['result']['affected_components'] for s in measured))
        row['delta_rows'] = sorted(set(s['delta_rows'] for s in measured))
        assert all(s['result']['delta_lag'] == 0 for s in samples)
        if side == 'after':
            assert row['strategies'] == {'affected': 30}
            assert row['fallbacks'] == {'None': 30}
            assert row['affected_records'] == [1] and row['affected_components'] == [1]
            assert row['delta_rows'] == [2]
        output['populations'].append(row)
        for sample in measured:
            bound = sample['result']['source_boundary']['safe_bound']
            history = [h for h in data['graph_refresh_history'] if h['tick_watermark_lsn'] == bound]
            assert len(history) == len(sample['result']['node_results']), (side, population, sample['sample'], len(history))
            ordinary.extend(history)
    for node in sorted(set(h['logical_id'] for h in ordinary)):
        history = [h for h in ordinary if h['logical_id'] == node]
        output['ordinary_node_work'][node] = {
            'executions': len(history),
            'actions': dict(collections.Counter(h['action'] for h in history)),
            'duration_ms': {'p50': percentile([h['duration_ms'] for h in history], .5), 'p95': percentile([h['duration_ms'] for h in history], .95)},
        }
    for workload in data['additional_workloads']:
        result = workload['result']
        output['additional_workloads'].append({k: workload[k] for k in ['workload', 'population', 'changed_records', 'elapsed_ms']} | {k: result[k] for k in ['resolver_strategy', 'resolver_fallback_reason', 'affected_records', 'affected_components', 'component_checks', 'delta_row_count', 'delta_lag', 'effective_node_modes', 'stage_timings_ms']})
    output['database_counter_deltas'] = {k: metadata['database_counters_after'][k] - metadata['database_counters_before'][k] for k in ['blks_hit', 'blks_read', 'temp_bytes', 'temp_files', 'tup_returned', 'tup_fetched', 'tup_inserted', 'tup_updated', 'tup_deleted', 'active_time']}
    output['graph_queries'] = {g['logical_id']: g['contract']['query'] for g in data['graph']}
    summary['sides'][side] = output
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({side: value['populations'] for side, value in summary['sides'].items()}, indent=2))
